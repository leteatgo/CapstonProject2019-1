package com.example.insu0.miribom.Lists;

import android.graphics.Bitmap;

public class HomeRestaurantListItem {
    private String resName;
    private Bitmap resIcon;

    public HomeRestaurantListItem(String resName, Bitmap resIcon) {
        this.resName = resName;
        this.resIcon = resIcon;
    }

    public String getResName() {
        return resName;
    }

    public void setResName(String resName) {
        this.resName = resName;
    }

    public Bitmap getResIcon() {
        return resIcon;
    }

    public void setResIcon(Bitmap resIcon) {
        this.resIcon = resIcon;
    }
}
