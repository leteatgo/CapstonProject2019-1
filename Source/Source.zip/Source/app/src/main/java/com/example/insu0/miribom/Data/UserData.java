package com.example.insu0.miribom.Data;

public class UserData {

    private String emailAddr;
    private String pw;


}
