package com.example.insu0.miribom;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.insu0.miribom.Data.DataUtils;

import org.json.JSONException;
import org.json.JSONObject;

import static com.example.insu0.miribom.Data.DataUtils.hoursFormatter;

/* author ckddn
* */

public class RestaurantInfoActivity extends AppCompatActivity {

    private int resNo;
    private String name;
    private String mobile;
    private String address;
    private String hours;
    private String image;
    private byte[] imageDatas;
    private int totalPlaceNum, availablePlaceNum, reservablePlaceNum;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_info);
        resNo = getIntent().getIntExtra("resNo",-1);
        name = getIntent().getStringExtra("restName");
        address = getIntent().getStringExtra("address");
        mobile = getIntent().getStringExtra("mobile");
        hours = getIntent().getStringExtra("hours");
        image = getIntent().getStringExtra("image");

        totalPlaceNum = getIntent().getIntExtra("totalPlaceNum", 0);
        availablePlaceNum = getIntent().getIntExtra("availablePlaceNum", 0);
        reservablePlaceNum = getIntent().getIntExtra("reservablePlaceNum",0);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
//        int height = displayMetrics.heightPixels;
        ImageView restImageView = (ImageView) findViewById(R.id.restImageView);
        /* put Image*/
        try {
            JSONObject jsonObject = new JSONObject(image);
            String data = jsonObject.getString("data");
            String[] imageStrs = data.substring(1, data.length()-1).split(",");
            imageDatas = new byte[imageStrs.length];
            for (int i = 0; i < imageStrs.length; i++) {
                imageDatas[i] = DataUtils.intToByteArray(Integer.parseInt(imageStrs[i]));
            }
            Bitmap bmp = BitmapFactory.decodeByteArray(imageDatas, 0 , imageDatas.length);
            bmp = Bitmap.createScaledBitmap(bmp,width, (int)restImageView.getScaleY()*bmp.getHeight(), true);
            restImageView.setImageBitmap(bmp);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        TextView restName = (TextView) findViewById(R.id.restName);
        TextView telTextView = (TextView) findViewById(R.id.telTextView);
        TextView addrTextView = (TextView) findViewById(R.id.addrTextView);
        TextView lunchtimeTextView = (TextView) findViewById(R.id.lunchtimeTextView);
        TextView seatinfoTextView = (TextView) findViewById(R.id.seatinfoTextView);

        restName.setText(name);
        telTextView.setText(mobile);
        addrTextView.setText(address);
        lunchtimeTextView.setText(DataUtils.hoursFormatter(hours));
        seatinfoTextView.setText("현재 잔여 좌석: " + availablePlaceNum + "석");
    }

}
